function korr = Overlapcorr(w, N, r);
%
% Overlap correlation for a window function
% Eq 17 Harris 1978
% In:
% w - window function of length N
% r - overlap in fraction
%
% S Holm, Univ Oslo 19 May 2012
%
denom = sum(w.*w);

korr = 0;

for n = 1:fix(r*N)
    korr = korr + w(n).*w(n+(round((1-r)*N)));
end

korr =korr/denom;
return

