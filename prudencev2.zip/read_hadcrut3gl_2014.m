function [year, globaltemp] = read_hadcrut3gl_2014(yearly,firstyear, lastyear)
%
% Sverre  Holm 24.11.2014
% reads a longer version of the hadcrut3 dataset
%
filename = 'data\HadCRUT3-2014.txt';
fileID = fopen(filename);

if fileID < 0,
    disp(['Cannot open ',filename])
    disp([' '])
end

%data = fscanf(fileID,'%d%f%f%f%f%f%f%f%f%f%f%f%f%f %*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d',[14 Inf]);
data = fscanf(fileID,'%4d%*c%2d%f%*f%*f%*f%*f%*f%*f%*f%*f%*f%*f',[3 Inf]);
fclose(fileID);



% data(1,?) = 1850   - integer year 
% data(2,?) =    1   - integer month
% data(3,?) = -0.591 - real temperature

% extract yearly or monthly data from dataset
if yearly==1,
    disp('Cannot do yearly data - read montly and average!')
    
else
   nrdata = length(data);
   globaltemp = zeros(1,nrdata);
   year       = zeros(size(globaltemp));

   antall = length(data(1,:)); % no of monthly samples
   %antall = data(1,end)-data(1,1)+1; % no of years
   
   tell = 1;
   for aar = 1:antall % aar = fractional year
   % one sample on first day of each month:
   %     year(tell:tell+11) = data(1,aar) + linspace(0,1-tolvtedel,12);
   % one sample in the middle of each month:
   
        year(aar) = data(1,aar) + data(2,aar)/12 - 1/24; % place mid-month - disregard different lengths of month
        globaltemp(aar) = data(3,aar);
   end
end
% truncate dataset if required
%disp(['Data spans ',num2str(year(1)),' - ',num2str(year(end))])

if firstyear > year(1)
    indx = find(year >= firstyear);
    year = year(indx);
    globaltemp = globaltemp(indx);
end
%disp(['Data spans ',num2str(year(1)),' - ',num2str(year(end))])

if lastyear < year(end)
    % not so OK if lastyear is an integer and same year as firstyear
    indx = find(year <= lastyear); 
    year = year(indx);
    globaltemp = globaltemp(indx);
end
%disp(['Data spans ',num2str(year(1)),' - ',num2str(year(end))])

return