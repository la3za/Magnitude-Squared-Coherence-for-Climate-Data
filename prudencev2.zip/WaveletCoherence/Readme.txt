Crosswavelet and Wavelet Coherence
by Aslak Grinsted

http://www.glaciology.net/wavelet-coherence
http://noc.ac.uk/using-science/crosswavelet-wavelet-coherence