Matlab routines from the Weaclim toolbox by Vincent Moron


http://www.mathworks.com/matlabcentral/fileexchange/10881-weaclim