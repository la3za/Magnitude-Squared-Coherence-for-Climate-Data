%%
% prudence.m
% Compare global climate data with Sun movement data using 
% magnitude squared coherence estimated with weighted averaged periodograms
%
% (c) Sverre Holm, University of Oslo http://folk.uio.no/sverre
%                  version 1: 29.6.2015
%                  version 2: 6.7.2015 - same functionality as v 1, 
%                             split out routine randomPhaseMSC.m
%
% May be used for academic work by referring to 2015 paper below.
%
%
% Code for generating Figs. 1, 2, 3, 6, 7, 8, 9 in
% Sverre Holm, "Prudence in estimating coherence between planetary, solar
% and climate oscillations", Astrophys Space Sci, May 2015
%
% Also code for Figs. 4, 5 and data for Table 1 in
% Sverre Holm, "On the alleged coherence between the global temperature
% and the sun's movement", Journ Atmospher. Solar Terr. Physics (JASTP)
% 
%
% Runs with MATLAB Version: 8.2.0.701 (R2013b) 
% Signal Processing Toolbox Version 6.20 (R2013b)
%
% Main algorithm is that for finding magnitude squared coherence and for
% simulating its confidence interval using the random phase method
% i.e. calls ebusuzaki.m, mscohere.m, and randomPhaseMSC.m 
%
%
% Requires these files:
%   read_hadcrut3gl.m, read_hadcrut3gl_2014.m, read_Horizons2.m - for reading data from these files:
%   data/hadcrut3gl.txt, data/HadCRUT3-2014.txt; data/horizons_results-4811intervals.txt
%
%   Overlapcorr.m, MSCIndep.m for finding overlap correlation and independence threshold
%   randomPhaseMSC.m - for finding MSC with random phase versions of input data
%
%   From
%   http://www.mathworks.com/matlabcentral/fileexchange/30347-sigplot:
%   dsxy2figxy.m 
%
%   Date conversion libraries from Peter John Acklam:  
%   j2date.m, days2hms.m, yearnum.m, dayofyear.m, isleapyear.m, daysinyear.m 
addpath timeutil; 
%
%   ebusuzaki.m, stan.m for genersting random phase versions of input data (from Vincent Moron)
addpath weaclim;
%
%   Crosswavelet and Wavelet Coherence library by Aslak Grinsted
addpath WaveletCoherence;

 
JASTP2014 = input(['Enter 1 for JASTP 2014 or 0 for ASS 2015 paper (default): ']);
if isempty(JASTP2014),
    JASTP2014 = 0; % default = 2015 paper
end

if JASTP2014 == 0, % AAS2015 Astrophysics, Space Science
    lastyear = 2014.4;  % new data set 2014, Nov
    disp([' '])
    disp(['Reproducing ASS 2015 results with data to ',num2str(lastyear)])
    disp(['Figures of paper have numbers starting with 2015x'])
    disp([' '])
    %
    % No of simulations for finding MSC confidence intervals for ASS 2015 paper:
    %
    clear nnnsim;
    nnnsim = input(['Enter 1 for accurate/slow (default), 0 for fast/inaccurate confidence intervals: ']);
    if isempty (nnnsim),
        nsim = 1000; % value used in 2015 paper: slow and accurate 
    elseif nnnsim == 0
        nsim = 10; % fast version for testing program: fast and inaccurate
    else
        nsim = 1000;
    end
    revData = 1; % data is reversed and starts at newest sample
	ConfIntervalSim = 1; % Find confidence interval by random phase simulation
    
elseif JASTP2014 == 1, 
    lastyear = 2010.72;  % max
    disp([' '])
    disp(['Reproducing JASTP 2014 results with data to ',num2str(lastyear)])
    disp(['Figures of paper have numbers starting with 2014x'])
    disp([' '])
    revData = 0; % data starts at oldest sample
	ConfIntervalSim = 0; % use analytic value of confidence interval/independence threshold (white noise assumption)
    
else
    disp('No paper selected')
    break
end

firstyear = 1850;

if JASTP2014, % Journal of Atmospheric, Solar-Terresterial Physics 2014
    nsegs = 12*[20, 30, 40];
    betaSun = 7; %  Kaiser window parameter
    
else          % Astrophys Space Sci, May 2015
    nsegs = 12*[41, 73, 109]; % for 1850-2014 data:   
    betaSun = 6; % Kaiser window parameter
end

%
% specify detrending: dt1 - for SCMSS, dt2 - for global temperature:
%
if JASTP2014,
    dt1 = 0;
    dt2 = 1; % used for paper's power spectra  
    dt2 = 0; % used for paper's MSC (Main difference if dt2=1 is at 100 yrs)
else
    dt1 = 0; % remove mean of SCMSS data
    dt2 = 1; % remove linear trend of global temperature
    %dt2 = 2; % used by Scafetta 2014 ASS
end
%%%
conflevelMSC= 0.95; % for MSC estimator plots. (Only 0.90, 0.95, 0.99 allowed in Wang's routines)
Fs=12; % year
nfft   = 16384*4; % need a lot esp. for plot as a f(period)

%%% Read data %%%
yearly = 0;
if JASTP2014,
    [year1, globaltemp] = read_hadcrut3gl(yearly, firstyear, lastyear); 
else 
    % replaces 24.11.2014 with updated data that runs to May 2014
    [year1, globaltemp] = read_hadcrut3gl_2014(yearly, firstyear, lastyear);
end
txt1 = 'Hadcrut3';
[year3, radius, xH, yH, velocity] = read_Horizons2(firstyear, lastyear);
xinput = velocity;
cmt = 'SCMSS';

%%%%%%%%%%%%%%%%
if ~JASTP2014,
    figure(20151) % 2015 paper, figure 1
    %
    % Plot solar orbit in x, y-plane. Inspired by Scafetta 2000, fig 4
    %
    yr1 = 1980;
    yr2 = 2014;

    indx = find(year3 >= yr1 & year3 <=yr2); % assuming that yr1 > firstyear
    plot(xH(indx), yH(indx))
    title(['Solar orbit rel. center of mass of the solar system from ',num2str(yr1),' to ',num2str(yr2)])
    grid
    xlabel('x on the ecliptic (sun radius)')
    ylabel('y on the ecliptic (sun radius)')
    axis([-2.5 2.5 -2.5 2.5])
    axis('square')
    ind = min(indx);
    text(xH(ind), yH(ind),num2str(yr1))
    ind = max(indx);
    text(xH(ind), yH(ind),num2str(yr2))
end

%%%%%%%%%%%%%%%%



%
% Raw data in a single two-axis graph
% 19.11.2014
%
% fit linear and parabolic function
%
mn = mean(globaltemp); %
p1 = polyfit(year1,globaltemp,1); % fit 1. order polynomial
p2 = polyfit(year1,globaltemp,2); % fit 2. order polynomial
    
figure(20152); % paper 2015, figure 2
clf
hl1 = line(year1,globaltemp,'Color','k');

h11 = line(year1,polyval(p1,year1),'Color','g','LineStyle','-');
h11 = line(year1,polyval(p2,year1),'Color','b','LineStyle','-');
h11 = line(year1,ones(size(year1))*mn,'Color','r','LineStyle','-');

ax1 = gca;
set(ax1,'XColor','k','YColor','k')
ylim([-2, 1])
ylabel([txt1,' global temperature anomaly [  ^oC]'])
hText = text(2001,-1.9,num2str(year1(end)));
set([hText],'FontSize',6);
grid
xlabel('Year')
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
       
hl2 = line(year3,xinput,'Color','k','Parent',ax2);
hl2 = line(year3,ones(size(xinput))*mean(xinput),'Color','r','Parent',ax2);
ylim([8, 8+18])    
ylabel(['Magnitude of ',cmt,' [m/s]'])

figure(20153)
%
% raw data after subtracting linear and parabolic fits
%
clf
hl1 = line(year1,globaltemp-polyval(p1,year1),'Color','k');
ax1 = gca;
set(ax1,'XColor','k','YColor','k')
ylim([-2, 1])
ylabel([txt1,' - linear trend ^oC'])
hText = text(2001,-0.9,num2str(year1(end)));
set([hText],'FontSize',6);
grid
xlabel('Year')
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');  
hl2 = line(year1,globaltemp-polyval(p2,year1),'Color','k','Parent',ax2); % parabolic
ylabel([txt1,' - parabolic trend ^oC'])
ylim([-1, 2])    

%
% Preprocess raw data for mean, trend or parabolic subtraction
%

if dt1==0
    xinput     = detrend(xinput,'constant'); % remove mean - default
elseif dt1==1,
    xinput     = detrend(xinput); % remove linear trend
end

if dt2==0,
    globaltemp = detrend(globaltemp,'constant'); % remove mean
elseif dt2==1,
    globaltemp = detrend(globaltemp); % linear detrending
elseif dt2==2,
    globaltemp = globaltemp - polyval(p2,year1); % parabolic detrending
end

%
% Pre-processed input data in a single two-axis graph
% 19.11.2014
%
figure(9003)
clf
hl1 = line(year1,globaltemp,'Color','b');
ax1 = gca;
set(ax1,'XColor','k','YColor','k')
ylim([-2, 1])
ylabel([txt1,' global temperature anomaly [  ^oC]'])
hText = text(2001,-1.9,num2str(year1(end)));
set([hText],'FontSize',6);
grid
xlabel('Year')
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
       
hl2 = line(year3,xinput,'Color','k','Parent',ax2);
ylim([-6, 18])    
ylabel(['Magnitude of ',cmt,' [m/s]'])
title(['Detrending of SCMSS: ',num2str(dt1),', temp: ',num2str(dt2),', Reverse: ',num2str(revData)])

%%%%%%%%%%%%%%%%%%%%%%

%%
% Confidence Intervals
%
if ConfIntervalSim == 1,
    %
    % random phase perturbation
    %
    
    value = 1; % seed for random generator >0 => same random no's each time
    value = 0;
    
    disp(['Generating ',num2str(nsim),' random phase perturbed versions of input data ... '])

    [X]=ebisuzaki(globaltemp,nsim,value);
    [Y]=ebisuzaki(xinput,nsim,value);

    figure(9111)
    clf
    clr = ['b','r','g','c','k','b','r','g','c','k'];
    % plot 5 of the realizations of random phase perturbed series
    for ns = 1:min(nsim,5)
        subplot(2,1,1)
        hold on
        plot(X(:,ns),clr(1+mod(ns,length(clr))))
        title('Random phase perturbations of input data')
        hold off

        subplot(2,1,2)
        hold on
        plot(Y(:,ns),clr(1+mod(ns,length(clr)))) 
        hold off 
        %disp('Press to continue ')
        %pause
    end
end


if revData,
    xinput     = fliplr(xinput);
    globaltemp = fliplr(globaltemp);
    year1 = fliplr(year1);
    year3 = fliplr(year3);
end


fmaxxx = 1.1; % in spectral plots
%

if isempty(nsegs),
    break
end

nsegment0 = nsegs(1);
nsegmentMax = nsegs(end);
ind = 0;
indd = 1; % counter for dofs

for nsegment = nsegs, 

        nshift = 12    ; % 1 year
        nshift = 0.25*nsegment; % 75% overlap
        %
        % overlap should be 50 or 75% for accurate estimation of DOF:
        noverlap = nsegment-nshift; 

        disp('************')
        disp(['Segment length ',num2str(nsegment/12), ' years:'])
      
        if length(nsegs) > 1,
            disp('Press to continue')
            pause
        end
        
        %
        % *** globaltemp (in tx1) vs xinput which is solar movement, mainly SCMSS (in cmt) *** 
       
        window2 = kaiser(nsegment,betaSun);     
        nd0 = 2*length(xinput)/nsegment - 1; % 2*no of nonoverlapping segments - OK for well-tapered windows
                                             % -1 added 21.11.2014 <=> no of 50% overlapping segments
        overlapp = noverlap/nsegment;
        korr1 = Overlapcorr(window2, nsegment, overlapp); % overlap correlation
        nrsegs = 1+ fix((length(xinput)-nsegment)/nshift); % new 1 July 2013 
        disp(['No of segments ',num2str(nrsegs)])
            
        if (overlapp ~= 0.5 & overlapp ~= 0.75)
            disp(['NB! Non-supported overlap, DOF-estimate is incorrect !!!!'])
        end
               
        disp([num2str(100*overlapp),' % overlap of Kaiser(',num2str(betaSun),') window'])
        
        korr25 = Overlapcorr(window2, nsegment, 0.25); % overlap correlation
        korr50 = Overlapcorr(window2, nsegment, 0.5); % overlap correlation
        korr75 = Overlapcorr(window2, nsegment, 0.75); % overlap correlation
        
        disp(['Overlap correlation @ 75%: ',num2str(korr75),', 50%: ',num2str(korr50),', 25%: ',num2str(korr25)])
        
        if overlapp < 0.6
        %   formula ca OK for 0.5
            ndinv = (1 + 2*korr1*korr1)/nrsegs; % Eq. 19a for N>10 (first 2 terms), Harris 1978
            ndinv = ndinv -2*korr1^2/(nrsegs^2); % added more terms 21.11.2014
        
        else 
            % OK for 0.75
            ndinv = (1 +  2*korr1*korr1 + 2*korr50*korr50)/nrsegs ; % Eq 19b for N>10 (first 3 terms), Harris 1978
            ndinv = ndinv -2*(korr1^2 +2*korr50^2+3*korr25^2)/(nrsegs^2); % corrected 21.11.2014
        end
        
        nd = 1/ndinv;
        
        disp(['Approx # independent segments (short tapers) ',num2str(nd0), ', exact # ',num2str(nd)])
        txtstring = ['Segment ',num2str(nsegment/12), ', shift ',num2str(nshift/12),' yrs, # independent ',num2str(nd)];
%%        
        figure(20159); % paper 2015, figure 9 (with Nsegment = 73 years)
        %
        % 20.11.2014 - plot windows and overlap
        %
        
        clf
        for nrr = 1:nrsegs
            vindu = zeros(size(year1));
            nstart=1 + nshift*(nrr-1);
            nend = nstart+nsegment-1;
            vindu(nstart:nend) = window2;
            hold on
            if mod(nrr,2) | nrsegs==2
                grf = 'k- ';
            else
                grf = 'k: ';
            end
            plot(year1, vindu,grf(:))
            hold off   
        end
        if revData,
            xlabel(['Year, ',num2str(year1(nend)),' - ',num2str(year1(1))])
        else
            xlabel(['Year, ',num2str(year1(nend)),' - ',num2str(year1(end))])
        end
        title(['Windows: Kaiser(',num2str(betaSun),'), ',txtstring])
        
        mainText = ['d:',num2str(dt1),',',num2str(dt2),'; ',num2str(nsegment/12)];
        if revData,
            mainText = [mainText,', R'];
        end
        ndtext = sprintf('%2.2f',nd);
        
        
 %%     
        
        % ************ matlab's built-in function
        [Cxy2, f] = mscohere(xinput,globaltemp,window2,noverlap,nfft,Fs);
        period = 1./f;
         
        %
        % Code for statistics from 
        % ShouYan Wang, Suzhou Institute of Biomedical Engineering and
        % Technology, China:
        %
        %  [biasMSC,varMSC] = MSCstat(Cxy2,nd);
        %  stdMSC = sqrt(max(0,varMSC));
        %  [conflower,confupper]=getconfinterval(fix(nd),conflevelMSC,Cxy2);
        
        conflower = Cxy2; % faking the value
        confupper = Cxy2; % faking the value
             
        EI = MSCindep(conflevelMSC, nd); % Independence level
        
 %%       
        figure(9022)
        plot(f,Cxy2,'k')
        xlabel(['Frequency (1/year), ',txtstring]);
        ylabel(['MSC (conf level ',num2str(conflevelMSC),'), Kaiser(',num2str(betaSun),'), ',num2str(firstyear),'-',num2str(lastyear)])
        title(['Magnitude squared coherence: ',cmt,' - ',txt1]);
        grid
        axis([0 fmaxxx 0 1])
        axis([0 0.25 0 1])
        
        hText = text(0.01,0.95,[mainText,', ',ndtext]);
        
        maxMSC=max(Cxy2(fix((0.015/Fs)*nfft):fix((1/(4*Fs))*nfft)));
        indmax = find(Cxy2==maxMSC);
        yrmax = 1/f(indmax);
        disp(['Peak year ',num2str(yrmax)])
        

       %%
        % period - for paper in JASTP,  April 2014
        % 
        if (JASTP2014),
            figure(2014); % paper 2014, figures 4-5 (table 1)
           
%             if nd > 5
%                 semilogx(period, Cxy2, period, EI*ones(size(f)),'g--', period, conflower,'r-.',period ,confupper,'r-.')
%                 legend('MSC', 'Independence threshold', '95% Confidence','Location','NorthEast')
%             else
                semilogx(period, Cxy2, period, EI*ones(size(f)),'g--') 
                legend('MSC', 'Independence threshold','Location','NorthEast')
%             end
            xlabel(['Period (years)']);
            grid
            axis([4 100 0 1])
            title('Figs. 4-5')
       
        end
        
 %%
       figure(93220)
       confMSC = [0.5 0.8 0.9 0.95 .98 .99 0.999];
       EI = MSCindep(confMSC, nd);
       
%        if nd > 5. 
%           semilogx(period, Cxy2,period, conflower,'r-.',period ,confupper,'r-.')
%           legend('MSC', '95% Confidence','Location','NorthEast')
%        else
          semilogx(period, Cxy2)
%        end

        if nd>=2
        hold on
            for iii = 1:length(confMSC)
                if EI(iii) <0.96  % changed from 0.95 19.11.2014
                    semilogx(period,EI(iii)*ones(size(f)),':')
                    text(100-25, EI(iii)+.02,num2str(confMSC(iii)));
                end
            end
            hold off
        end
        axis([4 100 0 1])
        hText = text(65,0.03,[mainText,', ',ndtext]);
        set([hText],'FontSize',6);       
        
        %%
       
        if ConfIntervalSim == 1,
            %
            % do random phase simulation for determing 95% confidence interval of MSC
            %
            % loop over # of random phase perturbations
            %
            
            clear Cxy
            nfft2 = nfft/4;
            Cxy = zeros(nsim, 1+nfft2/2);

            tic
            %%%%%%%%%%%%%%%%%%%%%%%%
            [Cxy, f] = randomPhaseMSC(xinput, globaltemp, X, Y, nsim, window2, noverlap, nfft2, Fs, 1);
            %%%%%%%%%%%%%%%%%%%%%%%%
            toc
            n95a = fix(nsim*conflevelMSC); % index the percentile for the confidence interval (e.g. 0.95)
            
            figure(2015); % paper 2015, figures 6-8
            period2 = 1./f;
            semilogx(period,Cxy2,'k',period2,Cxy(n95a,:),'r-.'); %,period2,max(Cxy(:,:)),'b-.',period2,min(Cxy(:,:)),'g-.')
           
            xlim([5 100])
            ylim([0 1])
            hText = text(60,0.03,[mainText,', ',ndtext]);
            set([hText],'FontSize',6);
            xlabel('Period [years]')
            ylabel('Magnitude squared coherence (MSC)')
            ax = gca;
            set(ax,'XTick',[5; 7; 10; 15; 20; 30; 40; 50; 60; 70; 80; 90])
            title('Figs. 6-8')
        end
        
        %
        % plot all MSC estimates in same figure
        % 19.11.2014
        %
%%
        figure(93221)
        clr = ['b- ';'g: ';'r-.';'k-.';'c--';'m: ';'g: ';'r-.';'c--';'k-.';'m: '];

        if nsegment == nsegment0
            ind = 0;
        end
        if nsegment0 ~= nsegmentMax & nsegment ~= nsegment0
            hold on
        end

        ind = ind+1;
        semilogx(period, Cxy2,clr(ind,:))
        hold off
        axis([4 100 0 1])
        title(['MSC for segment lengths ',num2str(nsegment0/12), ' - ',num2str(nsegmentMax/12)])
        xlabel(['Period (years)']);        
%%
       neff(indd) = nd;
       nseggs(indd) = nsegment;
       nrrrsegs(indd) = nrsegs;
       indd = indd+1;
       
%%%
end % loop over segments

if JASTP2014
    
    %%
    % Burg (= MEM) and Periodogram spectrum analysis of global temperature
    % using Signal Processing Toolbox functions
    %
    nsegment = 60; % 60 yrs;
    nshift = 1    ; % 1 year
    myorder = fix(800/160*nsegment);
    betaTemp = 3;
    
    disp('************')
    disp(['Periodogram and Burg(',num2str(myorder),') spectral analysis of SCMSS data, ',...
        num2str(firstyear),' - ',num2str(lastyear), ' ... '])

    year = year1;
    x = detrend(globaltemp); % linear detrending
    no_t =  fix(max(year))- fix(min(year))-nsegment+1;

    BurgPxx = zeros(1+nfft/2,no_t);
    pp = zeros(nfft,no_t);
    t = zeros(1,no_t);


    ystart = year(1);
    ind = 1;
    yend = year(length(year));
    while ystart + nsegment < yend
        ind1 = find(year == ystart);
        ind2 = find(year == ystart+nsegment)-1;
        xdetrended = detrend(x(ind1:ind2),'constant'); % subtract mean of segment

        BurgPxx(:,ind) = pburg(xdetrended,myorder,nfft,Fs);
        pp(:,ind) = abs(fft(xdetrended.*kaiser(length(xdetrended),betaTemp)',nfft));
        t(ind) = year(ind1) + (year(ind2)-year(ind1))/2; 

        ystart = ystart + nshift;
        ind = ind+1;
    end
    
    
    figure(20141); % Fig. 1
    clf
    surf(t,f,abs(pp(1:1+nfft/2,:).^0.4),'EdgeColor','none'); 

    axis xy; axis tight; 
    colormap(jet); 
    view(0,90);
    xlabel(['Year']);
    ylabel('Frequency (1/year)');
    title(['Temperature, periodogram, Kaiser(',num2str(betaTemp),')'])
    
    ax = axis;
    axis([ax(1) ax(2) 0 0.25])

    for aar = [6.0 6.5 7.5 8.2 9.1 10.4 12 14.9 21 30.1 62.2]  ; % Scafetta's peaks
        [arrowx,arrowy] = dsxy2figxy(gca, [ax(2)+4 ax(2)], [1/aar 1/aar]);
        har = annotation('textarrow',arrowx,arrowy);
        content = [num2str(aar)];
        set(har,'String',content,'Fontsize',8)
    end

    colorbar('WestOutside')  


    figure(20142)% Fig. 2
    clf
    N = fix((0.25/12) * nfft); 
    nn = length(t);
    
    % for paper  ( Corrigendum May 2014)
        surf(t,f,10*log10(abs(BurgPxx(:,1:nn))),'EdgeColor','none'); 
        %% autoscales color axis:   
        %surf(t,f(1:N),10*log10(abs(BurgPxx(1:N,1:nn))),'EdgeColor','none');
        
    axis xy; axis tight; 
    colormap(jet); 
    view(0,90);
    xlabel(['Year']);
    ylabel('Frequency (1/year)');
    title(['Temperature, Burg MEM spectral analysis, order ',num2str(myorder)])
    
    ax = axis;
    axis([ax(1) ax(2) 0 0.25])

    for aar = [6.0 6.5 7.5 8.2 9.1 10.4 12 14.9 21 30.1 62.2]
        [arrowx,arrowy] = dsxy2figxy(gca, [ax(2)+4 ax(2)], [1/aar 1/aar]);
        har = annotation('textarrow',arrowx,arrowy);
        content = [num2str(aar)];
        set(har,'String',content,'Fontsize',8)
    end
    colorbar('WestOutside')  
     
end


if JASTP2014
    %
    % spectral analysis of SCMSS
    %
    nsegment = 60; % years;
    nshift   =  1; % year
    myorder = fix(800/160*nsegment); % AR-order
    %
    % Due to different span of data in time compared to coherence analysis
    % above, data is reread from file here
    %
    firstyear2 = 1750;
    lastyear2 = 2100; 
    [year, radius, xH, yH, velocity] = read_Horizons2(firstyear2, lastyear2);
    xinput = velocity;
    
    f=Fs*(0:nfft/2)/nfft; % frequency axis
    
    disp('************')
    disp(['Burg(',num2str(myorder),') spectral analysis of SCMSS data, ',...
        num2str(firstyear2),' - ',num2str(lastyear2), ' ... '])
  
    no_t =  fix(max(year))- fix(min(year))-nsegment+1;

    BurgPxx3 = zeros(1+nfft/2,no_t);
    t3 = zeros(1,no_t-1); % 1 less

    ystart = year(1);
    ind = 1;
    yend = year(length(year));
    nrsamples = length(year);

    for ind = 1:(nrsamples-nsegment*12)/(nshift*12)
        % 
        % loop over segments of length nsegment years, 
        % shifted by nshift years
        %
        ind1 = 1 + (ind-1)*nshift*12;
        ind2 = ind1 + 12*nsegment - 1;
        xdetrended = detrend(xinput(ind1:ind2),'constant'); % remove mean per segment
        BurgPxx3(:,ind) = pburg(xdetrended,myorder,nfft,Fs);
        t3(ind) = year(ind1) + (year(ind2)-year(ind1))/2;
    end

    figure(20143)
    clf
    
    N = fix((0.25/12) * nfft); 
    nn = length(t3);
    % for paper  ( Corrigendum May 2014)
        surf(t3,f(1:N),10*log10(abs(BurgPxx3(1:N,1:nn))),'EdgeColor','none');
    
    axis xy; axis tight; 
    colormap(jet); 
    view(0,90);
    caxis([-61.5, 48.5])
    xlabel(['Year (window length ',num2str(nsegment), ' years)']);
    ylabel('Frequency (1/year)');
    title([cmt,', Burg MEM spectral analysis, order ',num2str(myorder)])
    
    ax = axis;
    for aar = [5.9 6.6 7.5 8.1 9.8 11.8 14.2 20.2 30.5 59.9]
        [arrowx,arrowy] = dsxy2figxy(gca, [ax(2)+12 ax(2)], [1/aar 1/aar]);
        har = annotation('textarrow',arrowx,arrowy);
        content = [num2str(aar)];
        set(har,'String',content,'Fontsize',8)
    end
    
    colorbar('WestOutside')
    %%%%%%%%%%%%%%%%%%%    
end

%%%%%%%%%%%%%% Uncomment from here if you don't want wavelet spectra %%%%%%
if ~JASTP2014
    
    if revData,
        %
        % reverse data back to normal if it was time-reverse
        %
        xinput     = fliplr(xinput);
        globaltemp = fliplr(globaltemp);
        year1 = fliplr(year1);
        year3 = fliplr(year3);
    end

    
    %%
    %%%%%% Wavelet analysis %%%%%%
    % First we load the two detrended time series into the matrices d1 and d2.
    seriesname={'Hadcrut3' 'Solar velocity'};

    clear d1
    clear d2
    d1(:,1) = year1; % ender p� 2010.708333333334
    d1(:,2) = globaltemp;

    d2(:,1) = year3; % ender p� 2010.706357861411
    % little adjustment as there are minimal differences on the time axis
    d2(:,1) = year1;
    d2(:,2) = xinput;

    figure(20154); % paper 2015, figure 4
    tlim=[min(d1(1,1),d2(1,1)) max(d1(end,1),d2(end,1))];
    subplot(2,1,1);
    wt(d1);
    title(seriesname{1});
    set(gca,'xlim',tlim);

    subplot(2,1,2)
    wt(d2)
    title(seriesname{2})
    set(gca,'xlim',tlim)

% %% Wavelet coherence (WTC)
%         % The WTC finds regions in time frequency space where the two time series co-vary 
%         % (but does not necessarily have high power).
        figure(20155)
        clf
        
        [Rsq,period,scale,coi,sig95] = wtc(d1,d2,'MakeFigure',1,'mcc',0); % No Monte Carlo: no plot of Confidence Interval
       
        title(['WTC: ' seriesname{1} '-' seriesname{2} ] )
% 
end
%%%%%%%%%%%%%% Uncomment until here if you don't want wavelet spectra %%%%%%
