function [Cxy, f] = randomPhaseMSC(x, y, X, Y, nsim, window, noverlap, nfft2, Fs, dispWait)
%
% Find magnitude squared coherence between real data sets and their random
% phase versions (from ebusuzaki.m), then find statistics
%
% (c) Sverre Holm, University of Oslo 6.7.2015,  http://folk.uio.no/sverre
%
% May be used for academic work by referring to paper below.
% 
% Sverre Holm, "Prudence in estimating coherence between planetary, solar
% and climate oscillations", Astrophys Space Sci, May 2015
%
%
% Requires mscohere from Signal Processing Toolbox
%
% Input:
%   x, y           - the two input data series
%   X, Y(:,nsim)   - random phase perturbed version of xinput, yinput
%                    from ebusuzaki.m
%   nsim           - no of different random phase perturbed versions
%   window         - window function for use on segment of input data
%   noverlap       - no of samples of overlap between segments
%   nfft2          - no of samples in msc estimate
%   Fs             - sampling frequency
%   dispWait       - 1 for display of waitbar
%
% Output:
%   Cxy            - max of coherence between input data and rqandom phase perturbed data
%                    sorted by coherence value
%   f              - vector of frequencies for msc estimators         
%
if dispWait,
    fprintf(1,'    0');
    hwait = waitbar(0,['Coherence of randomized phase data,', num2str(nsim)]);     
end

%%%%%%%%%%%%%%%%%%%%%%%%
for ns = 1:nsim
    %
    % coherence between actual input data (x,y) and random phase perturbed
    % data (X,Y):
    [Cxy12, f] = mscohere(x,X(:,ns),window,noverlap,nfft2,Fs);
    [Cxy21, f] = mscohere(Y(:,ns),y,window,noverlap,nfft2,Fs);

    Cxy(ns,:) = max(Cxy12,Cxy21); % approx Poluianov's approach

    if dispWait,
        waitbar(ns/nsim);
        fprintf('\b\b\b\b\b%5d',ns) 
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%
Cxy = sort(Cxy); % sort by coherence value per frequency

if dispWait,
    fprintf('\n');
    close(hwait);
end
end