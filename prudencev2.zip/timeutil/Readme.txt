Time and date utilities
Peter John Acklam
from http://home.online.no/~pjacklam/matlab/software/util/timeutil/