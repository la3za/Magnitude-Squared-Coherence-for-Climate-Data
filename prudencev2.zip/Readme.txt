Main program is prudence.m
Code written by Sverre Holm, University of Oslo
June/July 2015
Web home for code http://www.mn.uio.no/ifi/english/people/aca/sverre/climate.html