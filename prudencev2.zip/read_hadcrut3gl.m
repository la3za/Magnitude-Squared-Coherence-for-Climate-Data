function [year, globaltemp] = read_hadcrut3gl(yearly,firstyear, lastyear)
%
%  Sverre Holm, Univ Oslo 19 May 2012
%

filename = 'data/hadcrut3gl.txt';
fileID = fopen(filename);
%C = textscan(fileID,'%d%f%f%f%f%f%f%f%f%f%f%f%f%f',1);
data = fscanf(fileID,'%d%f%f%f%f%f%f%f%f%f%f%f%f%f %*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d%*d',[14 Inf]);
fclose(fileID);

% extract yearly or monthly data from dataset
if yearly==1,
    year = data(1,:);
    globaltemp =data(14,:);
else
   nrdata = length(data)*12;
   globaltemp = zeros(1,nrdata);
   year       = zeros(size(globaltemp));

   tolvtedel = 1/12;
   antall = length(data(1,:));
   tell = 1;
   for aar = 1:antall
   % one sample on first day of each month:
   %     year(tell:tell+11) = data(1,aar) + linspace(0,1-tolvtedel,12);
   % one sample in the middle of each month:
        year(tell:tell+11) = data(1,aar) + 1/24 + linspace(0,1-tolvtedel,12);
        globaltemp(tell:tell+11) = data(2:13,aar);
        tell = tell + 12;
   end
end
% truncate dataset if required

if firstyear > year(1)
    indx = find(year >= firstyear);
    year = year(indx);
    globaltemp = globaltemp(indx);
end

if lastyear < year(length(year))
    indx = find(year <= lastyear);
    year = year(indx);
    globaltemp = globaltemp(indx);
end
return