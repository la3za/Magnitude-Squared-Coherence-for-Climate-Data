function  EI = MSCindep(PI, nd);
% 
% Function for finding level at which MSC for sure is greater than 0
% PI - independence level, typ 0.95
% nd - no of independent averages
%
%   Independence level of 2004 Wang J.Neural Methods, Eqs 10-11
%   Better in Carter 1987, Proc IEEE, Eqs 13-15
%   expressed with detection theory, i.e. with P_False
%
% Sverre Holm, Univ Oslo 19 May 2012
%
Pf = 1-PI;
EI = 1 - Pf.^(1/(nd-1));

end

